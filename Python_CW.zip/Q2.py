# student number: C1893753

def pluralize ( word ):
    plural = ''
    status = ''
    vowels = ('a','e','i','o','u') # A Tuple containing all vowels.
    if word == "" :
        status = 'empty_string'
    elif word.endswith('s'):
        plural = word # If a word ends with 's', the same word will be returned.
        status = 'already_in_plural' 
    elif check_proper_noun(word): 
        plural = word # A proper noun cannot be pluralized.
        status = 'proper_noun'
    else : 
        if word.endswith(vowels):
            plural = word + 's' # e.g. banana --> bananas, chocolate --> chocolates etc.
            status = 'success'
        elif word.endswith( 'y' ) and word[-2] not in vowels: 
            plural = word[: -1 ] + 'ies' # e.g. University --> Universities, but Toy --> Toys.
            status = 'success'
        elif word.endswith('f'): 
            plural = word[: -1 ] + 'ves' # e.g. Handkerchief --> Handkerchieves
            status = 'success'
        elif word.endswith('z' ) or word[-2:] == ('ch' or 'sh'): 
            plural =  word + 'es' # e.g. buzz --> buzzes, coach --> coaches, fish --> fishes etc.
            status = 'success'
        else : 
            plural = word + 's' # If none of the above conditions are satisfied, we will add 's' with the word.
            status = 'success'
    result = {'plural' : plural, 'status': status}
    return(result)

def check_proper_noun(word):
   with open("proper_nouns.txt") as f:
    list_of_p_nouns = f.readlines()
    for p_noun in list_of_p_nouns:
      if (p_noun.strip() == word.lower()):
        return True
    return False



### --- IMPORTANT: DO NOT REMOVE OR CHANGE THE CODE BELOW ---
TEST_CASES = """failure
food
Zulma
injury
elf
buzz
computers
PCs

highway
presentation
pouch
COVID-19
adam""".split('\n')

if __name__ == '__main__':

  for test_noun in TEST_CASES:

    print(test_noun,'-->',pluralize(test_noun))
    print('----')