# student number: C1893753

import re # Regular expression is imported.
    
def function_renamer(code): # Function returns Hash, Camel case, All caps values and New changed code.
    lists = re.findall('def (\w[a-z\wA-Z\w0-9\w]+)[(]',code) # Searching the function name from the given code
    d={} # Empty dictionary is declared.
    for f_name in lists:
        hash_value = hash(f_name) # Calculating hash value
        new_f_name = camel_case(f_name) 
        code = code.replace(f_name,new_f_name)
        newcode = code
        d[f_name]={'hash':hash_value,'camelcase':new_f_name,'allcaps':f_name.upper()}

    return (d,newcode)
         
def camel_case(f_name): # Function to convert function name into camel case.
  if ('_' in f_name) :
    count = 0
    for char in f_name: # Checks leading '_' index.
      count +=1
      if char!='_':
        break
    v = f_name[count-1:] # Works on function name removing leading '_'
    a = v.replace('_'," ")
    x = a.title()
    z = x.replace(' ',"")
    final = f_name[0:count-1]+z # Adds leading '_' back to changed camel case function name

  elif ('_' not in f_name):
        final = f_name
  return final

       
### --- IMPORTANT: DO NOT REMOVE OR CHANGE THE CODE BELOW ---
if __name__ == '__main__':
    # Example 1
    testcases = {
        'example 1':
"""
def add_two_numbers(a, b):
  return a + b

print(add_two_numbers(10, 20))
""",
    'example 2' :
"""
def _major_split(*args):
  return (args[:2], args[2:])

def CheckTruth(t = True):
  print('t is', t)
  return _major_split([t]*10)

x, y = _major_split((10, 20, 30, 40, 50))
CheckTruth(len(x) == 10)
"""
    }
    for key, code in testcases.items(): 
        print(f'--- {key} ---')
        out = function_renamer(code)
        if not isinstance(out, tuple) or len(out)!=2:
            raise TypeError('function_renamer should return a tuple of length 2')
        d, newcode = out
        if not isinstance(d, dict):
            raise TypeError('return argument d should be a dictionary')
        if not isinstance(newcode, str):
            raise TypeError('return argument code should be a string')
        print('d = ', d)
        print('\ncode:')
        print(newcode)