# student number: C1893753

def do_arithmetic(x,y,op): # Here 'x' and 'y' are arbitrary Real Numbers and 'op' is a string representing the operation to be performed.
  if (op == 'add'):
   return (float (add(x,y))) # Operation to add two arguments.
  elif (op == 'subtract'):
    return (float (subtract(x,y))) # Operation to subtract one argument from another.
  elif (op == 'multiply'):
    return (float (multiply(x,y))) # Operation to multiply two arguments.
  elif (op == 'divide'):
    return (divide(x,y)) # Operation to divide one argument by another.
  elif (op == ''):
    return (float (add(x,y))) # If 'op' is not specified, it must default to 'add'.
  else:
    print ('Unknown operation') # Here 'op' is specified, but it is not one of the four operations.
    return 

def add(x,y): # Addition.
   return (x+y) 
def subtract(x,y): # Subtraction.
  return (x-y)
def multiply(x,y): # Multiplication.
  if x*y == -0.0 :
    return 0.0 # Zero is a Neutral Number, neither positive nor negative.
  return (x*y)
def divide(x,y): # Division.
  if y == 0 :
    return 'None'
  else :
   return (float (x/y))
 

def sum_of_digits(s): # Function to calculate sum of the digits in a string.
    if s == '':
        return 0
    else:
        sum = 0
        for x in s:
          if x.isnumeric() == True: # Checks each character of a string.
            y = int(x)
            sum = sum + y
        return sum


### --- IMPORTANT: DO NOT REMOVE OR CHANGE THE CODE BELOW ---
if __name__ == '__main__':
    testcases = {'do_arithmetic': [(10, 4, 'add'), (2, 3, 'multiply')],
    'sum_of_digits':[("123",), ("10a20",)]}

    print('\n-- do_arithmetic testcases --')
    for args in testcases['do_arithmetic']:
        print('input:', str(args))
        print('output:', do_arithmetic(*args))
        print('-----------')

    print('\n-- sum_of_digits testcases --')
    for args in testcases['sum_of_digits']:
        print('input:', str(args))
        print('output:', sum_of_digits(*args))
        print('-----------')